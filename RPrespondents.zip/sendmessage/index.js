
const dbName = "Research"
window.onload = function (){
  const resetButton = document.getElementById("resetStats")
  resetButton.onclick=function(){
    indexedDB.deleteDatabase(dbName)
    alert("Db deleted")
    window.location.reload()
  }
}
const request = indexedDB.open(dbName,1)
const preparedData = [
  {
    id: "q1",
    data: {
      rate1: 0,
      rate2: 0,
      rate3: 0,
      rate4: 0,
      rate5: 0
    }
  },
  {
    id: "q2",
    data: {
      rate1: 0,
      rate2: 0,
      rate3: 0,
      rate4: 0,
      rate5: 0
    }
  },
  {
    id: "q3",
    data: {
      never: 0,
      rarely: 0,
      sometimes: 0,
      often: 0,
      always: 0
    }
  },
  {
    id: "q4",
    data: {
      never: 0,
      rarely: 0,
      sometimes: 0,
      often: 0,
      always: 0
    }
  },
  {
    id: "q5",
    data: {
      yes: 0,
      no: 0
    }
  }
]

const questions={
  q1: "How knowledgeable do you consider yourself about basic cybersecurity principles and best practices?",
  q2: "How confident are you in your ability to identify phising emails?",
  q3: "How often do you update your passwords for online accounts?",
  q4: "How frequently do you engage in activities such as downloading software or files from unknown sources?",
  q5: "Have you received any formal training or education in cybersecurity?"
}

request.onsuccess = (event) =>{
  const db = event.target.result
  const resObject = db.transaction("responds","readwrite")
  const objStore = resObject.objectStore("responds")
  const getAll = objStore.getAll()
  const submit = document.getElementById("submit")
  getAll.onsuccess=(event)=>{
    const list = event.target.result
    list.forEach((respond)=>{
      const iD = `${respond.id}-rates`
      const parent = document.getElementById(iD)
      for (key in respond.data){
        const th = document.createElement("th")
        th.innerText = respond.data[key]
        parent.appendChild(th)
      }
    })
  }
  submit.onclick=(event)=>{
  const resObject = db.transaction("responds","readwrite")
  const objStore = resObject.objectStore("responds")
  const name = document.getElementById("name")
  const pangkat = document.getElementById("pangkat")
  const getAll = objStore.getAll()
  let SubmitText = `Submitted by: ${name.value}\nSection: ${pangkat.value}\n`
  getAll.onsuccess=(event)=>{
    const list = event.target.result
    list.forEach((respondent)=>{
      let NewText = `${questions[respondent.id]}\n`
      for (key in respondent.data){
        NewText += `${key}: ${respondent.data[key]}\n`
      }
      SubmitText+=`${NewText} \n`
    })
    sendMessage(SubmitText)
  }
  }
}
request.onerror = (event) =>{
  console.log("unable to open db")
}
request.onupgradeneeded = (event) =>{
  const db = event.target.result
  const resobject = db.createObjectStore("responds",{keyPath:"id"})
  resobject.createIndex("data","data")
  
  resobject.transaction.oncomplete=(event)=>{
    const respondsObj =
    db.transaction("responds","readwrite").objectStore("responds")
    preparedData.forEach((data)=>{
      respondsObj.add(data)
    })
  }
}

function sendMessage(text){
  fetch("https://discord.com/api/webhooks/1232007755699585095/cxP-otbwg4btsI-hSFzO_iXgQUaCFtLsijrVH6oRrFjNqqO1K1pT8AmiJNO2XKUPPbfH",
    {
  body: JSON.stringify({
    content: text,
  }),
  headers: {
    "Content-Type": "application/json",
  },
  method: "POST",
})
  .then(function (res) {
    console.log(res);
  })
  .catch(function (res) {
    console.log(res);
  });
}